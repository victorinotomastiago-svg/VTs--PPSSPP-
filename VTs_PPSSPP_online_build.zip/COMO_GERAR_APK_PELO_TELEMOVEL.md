# VTs PPSSPP — gerar APK sem PC

Este projeto está preparado para ser compilado na nuvem pelo GitHub Actions.

## Pelo telemóvel

1. Crie/entre numa conta GitHub.
2. Crie um repositório chamado `VTs-PPSSPP`.
3. Envie os ficheiros deste projeto para o repositório, mantendo as pastas.
4. Abra o separador **Actions**.
5. Escolha **Gerar APK VTs PPSSPP**.
6. Toque em **Run workflow**.
7. Quando terminar, abra a execução concluída e procure **Artifacts**.
8. Baixe `VTs-PPSSPP-APK`, extraia o ZIP e instale o `app-debug.apk`.

Importante: esta versão é o protótipo. O APK terá o menu e as telas do VTs PPSSPP, mas ainda não contém o servidor real de partidas PPSSPP nem pagamentos em dinheiro.
