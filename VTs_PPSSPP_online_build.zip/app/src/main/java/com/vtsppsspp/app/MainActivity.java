package com.vtsppsspp.app;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.content.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root;
    int blue = Color.rgb(25,167,255), bg = Color.rgb(6,17,31), panel = Color.rgb(11,32,54);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        showHome();
    }

    TextView title(String s, int size) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(size);
        t.setPadding(8,16,8,16);
        return t;
    }
    Button btn(String s) {
        Button b = new Button(this);
        b.setText(s); b.setTextColor(Color.WHITE); b.setTextSize(15);
        b.setAllCaps(false);
        b.setBackgroundColor(blue);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, 58);
        p.setMargins(0,8,0,8); b.setLayoutParams(p);
        return b;
    }
    void base(String heading) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(22,22,22,22); root.setBackgroundColor(bg);
        ScrollView sv = new ScrollView(this); sv.addView(root);
        setContentView(sv);
        root.addView(title("🎮  VTs PPSSPP", 27));
        root.addView(title(heading, 21));
    }
    void showHome() {
        base("Conecta. Joga. Vence.");
        TextView welcome=title("Bem-vindo à Arena VTs\nJogue PPSSPP, encontre adversários e participe de ligas.",16);
        welcome.setTextColor(Color.LTGRAY); root.addView(welcome);

        Button play=btn("🎮  JOGAR AGORA"); play.setOnClickListener(v->showPlay()); root.addView(play);
        Button league=btn("🏆  LIGA PRO"); league.setOnClickListener(v->showLeague()); root.addView(league);
        Button champ=btn("⚔️  VTs CHAMPIONS"); champ.setOnClickListener(v->showChamp()); root.addView(champ);
        Button rank=btn("🥇  RANKING"); rank.setOnClickListener(v->showRanking()); root.addView(rank);
        Button profile=btn("👤  MEU PERFIL"); profile.setOnClickListener(v->showProfile()); root.addView(profile);

        TextView low=title("📶 Modo económico\nSem transmissão de vídeo • comunicação otimizada • ideal para dados móveis",15);
        low.setTextColor(Color.rgb(150,220,180)); root.addView(low);
    }
    void showPlay() {
        base("Jogar Agora");
        root.addView(title("Escolha o modo",17));
        Button one=btn("1 VS 1  •  Duelo direto"); one.setOnClickListener(v->showRoom()); root.addView(one);
        Button two=btn("2 VS 2  •  Em dupla"); two.setOnClickListener(v->showRoom()); root.addView(two);
        Button back=btn("← Voltar"); back.setOnClickListener(v->showHome()); root.addView(back);
    }
    void showRoom() {
        base("Sala VTs #2847");
        root.addView(title("⚽ Victorino   VS   Procurando adversário...",18));
        root.addView(title("Modo: 1 VS 1\nJogo: FIFA / futebol no PPSSPP\nEntrada: Gratuita (versão de teste)",16));
        Button found=btn("🔎 Procurar adversário"); found.setOnClickListener(v->{
            Toast.makeText(this,"Adversário encontrado! Configure o PPSSPP para iniciar.",Toast.LENGTH_LONG).show();
        }); root.addView(found);
        Button conn=btn("🔗 Configurar conexão PPSSPP"); conn.setOnClickListener(v->showConnection()); root.addView(conn);
        Button back=btn("← Sair da sala"); back.setOnClickListener(v->showPlay()); root.addView(back);
    }
    void showConnection() {
        base("Conectar no PPSSPP");
        root.addView(title("Passos da partida",17));
        root.addView(title("1. Abra o PPSSPP\n2. Vá em Multiplayer → Ad Hoc\n3. Entre na mesma sala/servidor\n4. Escolha o jogo e inicie a partida\n\nNesta versão, a conexão real ao servidor ainda será adicionada.",16));
        Button back=btn("← Voltar"); back.setOnClickListener(v->showRoom()); root.addView(back);
    }
    void showLeague() {
        base("🏆 Liga Pro");
        root.addView(title("Escolha a equipa que vai representar",17));
        String[] teams={"Real Madrid","Barcelona","Liverpool","Arsenal","Chelsea","Bayern","PSG","Inter","Juventus","Manchester City"};
        for(String team:teams){
            Button b=btn("⚽ "+team);
            b.setOnClickListener(v->Toast.makeText(this,"Equipa escolhida: "+team,Toast.LENGTH_SHORT).show());
            root.addView(b);
        }
        Button back=btn("← Voltar"); back.setOnClickListener(v->showHome()); root.addView(back);
    }
    void showChamp() {
        base("⚔️ VTs Champions");
        root.addView(title("Temporada 1 • Inscrições de teste",17));
        root.addView(title("Grupos → Oitavas → Quartos → Semifinal → Final\n\nCada jogador representa a sua equipa e acumula pontos.",16));
        Button b=btn("🏟️ Ver grupos"); b.setOnClickListener(v->Toast.makeText(this,"Grupos carregados.",Toast.LENGTH_SHORT).show()); root.addView(b);
        Button back=btn("← Voltar"); back.setOnClickListener(v->showHome()); root.addView(back);
    }
    void showRanking() {
        base("🥇 Ranking");
        root.addView(title("POS.   JOGADOR             PTS\n1       Victorino              1420\n2       Player01                1350\n3       CR7_Gamer              1205\n4       Messi10                 1080",17));
        Button back=btn("← Voltar"); back.setOnClickListener(v->showHome()); root.addView(back);
    }
    void showProfile() {
        base("👤 Meu Perfil");
        root.addView(title("Victorino\nID: VTs4582\n\nVitórias: 48\nDerrotas: 12\nTaxa de vitória: 80%",17));
        Button back=btn("← Voltar"); back.setOnClickListener(v->showHome()); root.addView(back);
    }
}