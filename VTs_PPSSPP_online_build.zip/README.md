# VTs PPSSPP

Protótipo Android inicial da plataforma VTs PPSSPP.

## O que já existe
- Menu principal
- Jogar agora
- Salas 1v1
- Tela de configuração/conexão PPSSPP
- Liga Pro com escolha de equipa
- VTs Champions
- Ranking
- Perfil
- Mensagem de baixo consumo de dados

## Próximas etapas
1. Backend e contas reais
2. Matchmaking e salas online
3. Servidor multiplayer/relay compatível com o fluxo PPSSPP
4. Registo e validação de resultados
5. Painel administrativo
6. Antifraude
7. Campeonatos completos
8. Só depois: carteira/pagamentos e prémios em dinheiro, condicionados aos requisitos legais e de licenciamento aplicáveis.

## Como abrir
Abra a pasta no Android Studio e aguarde a sincronização do Gradle. Depois execute em um telefone Android ou emulador.
